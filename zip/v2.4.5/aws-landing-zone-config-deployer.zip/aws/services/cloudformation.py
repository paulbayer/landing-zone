###################################################################################################################### 
#  Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                           #
#                                                                                                                    #
#  Licensed under the Apache License Version 2.0 (the "License"). You may not use this file except in compliance     #
#  with the License. A copy of the License is located at                                                             #
#                                                                                                                    #
#      http://www.apache.org/licenses/                                                                               #
#                                                                                                                    #
#  or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES #
#  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions    #
#  and limitations under the License.                                                                                #
######################################################################################################################

#!/bin/python

import inspect
from os import environ
from botocore.exceptions import ClientError
from lib.decorator import try_except_retry
from aws.utils.boto3_session import Boto3Session

OPERATION_IN_PROGRESS_EXCEPTION = "Caught exception " \
                                  "'OperationInProgressException', handling " \
                                  "the exception..."


class StackSet(Boto3Session):
    def __init__(self, logger, **kwargs):
        self.logger = logger
        __service_name = 'cloudformation'
        self.max_concurrent_percent = int(environ.get('MAX_CONCURRENT_PERCENT', 100))
        self.failed_tolerance_percent = int(environ.get('FAILED_TOLERANCE_PERCENT', 10))
        self.region_concurrency_type = environ.get('REGION_CONCURRENCY_TYPE', 'PARALLEL').upper()
        super().__init__(logger, __service_name, **kwargs)
        self.cfn_client = super().get_client()

    @staticmethod
    def build_parameters(params):
        parameters = []
        for key, value in params.items():
            if type(value) == list:
                value = ",".join(map(str, value))
            parameters.append({'ParameterKey': key, 'ParameterValue': value})
        return parameters

    @try_except_retry()
    def describe_stack_set(self, stack_set_name):
        try:
            response = self.cfn_client.describe_stack_set(
                StackSetName=stack_set_name
            )
            return response
        except self.cfn_client.exceptions.StackSetNotFoundException:
            pass
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    @try_except_retry()
    def describe_stack_set_operation(self, stack_set_name, operation_id):
        try:
            response = self.cfn_client.describe_stack_set_operation(
                StackSetName=stack_set_name,
                OperationId=operation_id
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    @try_except_retry()
    def list_stack_instances_per_account(self, stack_name, account_id, max_results=20):
        try:
            response = self.cfn_client.list_stack_instances(
                StackSetName=stack_name,
                StackInstanceAccount=account_id,
                MaxResults=max_results
            )
            stack_instance_list = response.get('Summaries', [])
            next_token = response.get('NextToken', None)

            while next_token is not None:
                self.logger.info("Next Token Returned: {}".format(next_token))
                response = self.cfn_client.list_stack_instances(
                    StackSetName=stack_name,
                    StackInstanceAccount=account_id,
                    MaxResults=max_results,
                    NextToken=next_token
                )
                self.logger.info("Extending Stack Instance List")
                stack_instance_list.extend(response.get('Summaries', []))
                next_token = response.get('NextToken', None)
            return stack_instance_list
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    @try_except_retry()
    def list_stack_instances(self, **kwargs):
        try:
            response = self.cfn_client.list_stack_instances(**kwargs)
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    def create_stack_set(self, stack_set_name, template_url, cf_params, capabilities):
        try:
            parameters = self.build_parameters(cf_params)
            response = self.cfn_client.create_stack_set(
                StackSetName=stack_set_name,
                TemplateURL=template_url,
                Parameters=parameters,
                Capabilities=[capabilities],
                Tags=[
                    {
                        'Key': 'AWS_Solutions',
                        'Value': 'LandingZoneStackSet'
                    },
                ]
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    def create_stack_instances(self, stack_set_name, account_list, region_list):
        try:
            response = self.cfn_client.create_stack_instances(
                StackSetName=stack_set_name,
                Accounts=account_list,
                Regions=region_list,
                OperationPreferences={
                    'FailureTolerancePercentage': self.failed_tolerance_percent,
                    'MaxConcurrentPercentage': self.max_concurrent_percent,
                    'RegionConcurrencyType': self.region_concurrency_type
                }
            )
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'OperationInProgressException':
                self.logger.info("%s" % OPERATION_IN_PROGRESS_EXCEPTION)
                return {"OperationId": "OperationInProgressException"}
            else:
                message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                           'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
                self.logger.exception(message)
                raise

    def create_stack_instances_with_override_params(self, stack_set_name, account_list, region_list, override_params):
        try:
            parameters = self.build_parameters(override_params)
            response = self.cfn_client.create_stack_instances(
                StackSetName=stack_set_name,
                Accounts=account_list,
                Regions=region_list,
                ParameterOverrides=parameters,
                OperationPreferences={
                    'FailureTolerancePercentage': self.failed_tolerance_percent,
                    'MaxConcurrentPercentage': self.max_concurrent_percent,
                    'RegionConcurrencyType': self.region_concurrency_type
                }
            )
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'OperationInProgressException':
                self.logger.info("%s" % OPERATION_IN_PROGRESS_EXCEPTION)
                return {"OperationId": "OperationInProgressException"}
            else:
                message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                           'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
                self.logger.exception(message)
                raise

    def update_stack_instances(self, stack_set_name, account_list, region_list, override_params):
        try:
            parameters = self.build_parameters(override_params)
            return self.cfn_client.update_stack_instances(
                StackSetName=stack_set_name,
                Accounts=account_list,
                Regions=region_list,
                ParameterOverrides=parameters,
                OperationPreferences={
                    'FailureTolerancePercentage': self.failed_tolerance_percent,
                    'MaxConcurrentPercentage': self.max_concurrent_percent,
                    'RegionConcurrencyType': self.region_concurrency_type
                }
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'OperationInProgressException':
                self.logger.info("%s" % OPERATION_IN_PROGRESS_EXCEPTION)
                return {"OperationId": "OperationInProgressException"}
            else:
                message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                           'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
                self.logger.exception(message)
                raise

    def update_stack_set(self, stack_set_name, parameter, template_url, capabilities):
        try:
            parameters = self.build_parameters(parameter)
            return self.cfn_client.update_stack_set(
                StackSetName=stack_set_name,
                TemplateURL=template_url,
                Parameters=parameters,
                Capabilities=[capabilities],
                OperationPreferences={
                    'FailureTolerancePercentage': self.failed_tolerance_percent,
                    'MaxConcurrentPercentage': self.max_concurrent_percent,
                    'RegionConcurrencyType': self.region_concurrency_type
                }
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'OperationInProgressException':
                self.logger.info("%s" % OPERATION_IN_PROGRESS_EXCEPTION)
                return {"OperationId": "OperationInProgressException"}
            else:
                message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                           'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
                self.logger.exception(message)
                raise

    def delete_stack_set(self, stack_set_name):
        try:
            response = self.cfn_client.delete_stack_set(
                StackSetName=stack_set_name,
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    def delete_stack_instances(self, stack_set_name, account_list, region_list, retain_condition=False):
        try:
            response = self.cfn_client.delete_stack_instances(
                StackSetName=stack_set_name,
                Accounts=account_list,
                Regions=region_list,
                RetainStacks=retain_condition,
                OperationPreferences={
                    'FailureTolerancePercentage': self.failed_tolerance_percent,
                    'MaxConcurrentPercentage': self.max_concurrent_percent,
                    'RegionConcurrencyType': self.region_concurrency_type
                }
            )
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'OperationInProgressException':
                self.logger.info("%s" % OPERATION_IN_PROGRESS_EXCEPTION)
                return {"OperationId": "OperationInProgressException"}
            else:
                message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                           'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
                self.logger.exception(message)
                raise

    @try_except_retry()
    def describe_stack_instance(self, stack_set_name, account_id, region):
        try:
            response = self.cfn_client.describe_stack_instance(
                StackSetName=stack_set_name,
                StackInstanceAccount=account_id,
                StackInstanceRegion=region
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    def list_stack_set_operations(self, **kwargs):
        try:
            response = self.cfn_client.list_stack_set_operations(**kwargs)
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise


class Stacks(Boto3Session):
    def __init__(self, logger, **kwargs):
        self.logger = logger
        __service_name = 'cloudformation'
        super().__init__(logger, __service_name, **kwargs)
        self.cfn_client = super().get_client()

    @try_except_retry()
    def describe_stacks(self, stack_name):
        try:
            response = self.cfn_client.describe_stacks(
                StackName=stack_name
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    @try_except_retry()
    def describe_stacks_all(self, token=None):
        """
        Get all stacks (multiple API calls) and return one dict
        """
        try:

            if token:
                kwargs = {'NextToken': token}
            else:
                kwargs = {}

            response = self.cfn_client.describe_stacks(**kwargs)

            if 'Stacks' in response:
                return response
            else:
                self.logger.error(f'describe_stacks({kwargs}) returned no data')

        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise


    @try_except_retry()
    def get_stack_summary(self, stack_name):
        try:
            response = self.cfn_client.get_template_summary(StackName=stack_name)
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise


    @try_except_retry()
    def get_template_summary(self, template_url):
        try:
            response = self.cfn_client.get_template_summary(TemplateURL=template_url)
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise

    def update_stack(self, stack_name, parameters, template_url, capabilities):
        try:
            response = self.cfn_client.update_stack(
                StackName=stack_name,
                TemplateURL=template_url,
                Parameters=parameters,
                Capabilities=capabilities
            )
            return response
        except Exception as e:
            message = {'FILE': __file__.split('/')[-1], 'CLASS': self.__class__.__name__,
                       'METHOD': inspect.stack()[0][3], 'EXCEPTION': str(e)}
            self.logger.exception(message)
            raise
