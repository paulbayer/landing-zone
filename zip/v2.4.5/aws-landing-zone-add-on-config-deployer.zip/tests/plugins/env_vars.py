import os
import pytest


@pytest.hookimpl(tryfirst=True)
def pytest_load_initial_conftests():
    os.environ['LOG_LEVEL'] = 'info'
    os.environ['AWS_REGION'] = 'us-east-1'
    os.environ['UNLOCK_ROLE_ARNS'] = 'arn:aws:iam::account-id:root'
    os.environ['SSM_KEY_FOR_LOCK_DOWN_ROLE_ARNS'] = 'lock_down_role_arns_list'


