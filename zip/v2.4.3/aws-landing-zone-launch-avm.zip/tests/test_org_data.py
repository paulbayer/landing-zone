import os
import pytest
from lib.logger import Logger
from aws.services.ssm import SSM
from moto import mock_ssm
from moto import mock_sts
from moto import mock_iam
import launch_avm
import boto3

TESTS_DIR = './tests/'

logger = Logger(loglevel='info')


@pytest.fixture
def organizations_setup(org_client):
    security_map = {
        "AccountName": "security",
        "AccountEmail": "security@mock",
        "OUName": "Core"
    }
    log_archive_map = {
        "AccountName": "log-archive",
        "AccountEmail": "log-archive@mock",
        "OUName": "Core"
    }
    shared_services_map = {
        "AccountName": "shared-services",
        "AccountEmail": "shared-services@mock",
        "OUName": "Core"
    }

    test_map = {
        "AccountName": "Testing1",
        "AccountEmail": "test@mock",
        "OUName": "Test"
    }
    # create organization
    org_client.create_organization(FeatureSet="ALL")
    root_id = org_client.list_roots()["Roots"][0]["Id"]

    # create accounts
    security_account_id = org_client.create_account(
        AccountName=security_map['AccountName'],
        Email=security_map['AccountEmail'])["CreateAccountStatus"]["AccountId"]
    log_archive_account_id = org_client.create_account(
        AccountName=log_archive_map['AccountName'],
        Email=log_archive_map['AccountEmail'])["CreateAccountStatus"]["AccountId"]
    test_account_id = org_client.create_account(
        AccountName=test_map['AccountName'],
        Email=test_map['AccountEmail'])["CreateAccountStatus"]["AccountId"]
    shared_services_account_id = org_client.create_account(
        AccountName=shared_services_map['AccountName'],
        Email=shared_services_map['AccountEmail'])["CreateAccountStatus"]["AccountId"]

    # set environment variables
    os.environ['SECURITY_ACCOUNT_ID'] = security_account_id
    os.environ['LOG_ARCHIVE_ACCOUNT_ID'] = log_archive_account_id
    os.environ['TEST_ACCOUNT_ID'] = test_account_id
    os.environ['SHARED_SERVICES_ACCOUNT_ID'] = shared_services_account_id

    # create org units
    core_resp = org_client.create_organizational_unit(ParentId=root_id,
                                                      Name=security_map['OUName'])
    core_ou_id = core_resp["OrganizationalUnit"]["Id"]

    test_resp = org_client.create_organizational_unit(ParentId=root_id,
                                                      Name=test_map['OUName'])
    test_ou_id = test_resp["OrganizationalUnit"]["Id"]

    # move accounts
    org_client.move_account(
        AccountId=security_account_id, SourceParentId=root_id,
        DestinationParentId=core_ou_id
    )
    org_client.move_account(
        AccountId=log_archive_account_id, SourceParentId=root_id,
        DestinationParentId=core_ou_id
    )
    org_client.move_account(
        AccountId=shared_services_account_id, SourceParentId=root_id,
        DestinationParentId=core_ou_id
    )
    org_client.move_account(
        AccountId=test_account_id, SourceParentId=root_id,
        DestinationParentId=test_ou_id
    )
    yield


@mock_iam
@mock_sts
@mock_ssm
def test_lock_stack_set_role(organizations_setup):
    iam_client = boto3.client("iam", region_name="us-east-1")
    lock_flag = 'yes'
    stack_set_role = "AWSCloudFormationStackSetExecutionRole"
    ssm_setup(lock_flag)
    iam_role_setup(iam_client, stack_set_role)

    # define variables
    manifest_name = 'test_manifest_1.yaml'
    file_path = TESTS_DIR + manifest_name

    # call function to update stack_set_role
    core_accounts = launch_avm.update_lock_down_stack_sets_role_core_accounts(
        file_path,
        logger)
    logger.info(core_accounts)
    # check if all the core accounts were returned
    assert os.environ['SECURITY_ACCOUNT_ID'] in core_accounts
    assert os.environ['LOG_ARCHIVE_ACCOUNT_ID'] in core_accounts
    assert os.environ['SHARED_SERVICES_ACCOUNT_ID'] in core_accounts

    # check the non-core account is not returned
    assert os.environ['TEST_ACCOUNT_ID'] not in core_accounts

    role = iam_client.get_role(RoleName=stack_set_role)
    logger.info(role)
    assert role['Role']['AssumeRolePolicyDocument']['Statement'] == [
        {
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Principal": {
                "AWS": [
                    "\"arn:aws:iam::account-id:role/Role2\"",
                    "\"arn:aws:iam::account-id:role/Role1\""
                ]
            }
        }
    ]


@mock_iam
@mock_sts
@mock_ssm
def test_unlock_stack_set_role(organizations_setup):
    iam_client = boto3.client("iam", region_name="us-east-1")
    lock_flag = 'no'
    stack_set_role = "AWSCloudFormationStackSetExecutionRole"
    ssm_setup(lock_flag)
    iam_role_setup(iam_client, stack_set_role)

    # define variables
    manifest_name = 'test_manifest_1.yaml'
    file_path = TESTS_DIR + manifest_name

    # call function to update stack_set_role
    core_accounts = launch_avm.update_lock_down_stack_sets_role_core_accounts(
        file_path,
        logger)
    logger.info(core_accounts)
    role = iam_client.get_role(RoleName=stack_set_role)
    assert role['Role']['AssumeRolePolicyDocument']['Statement'] == [
        {
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::account-id:root"
                ]
            }
        }
    ]


def iam_role_setup(iam_client, role_name):
    # create mock iam role
    iam_client.create_role(
        RoleName=role_name,
        AssumeRolePolicyDocument="some policy",
        Description="test",
    )


def ssm_setup(flag):
    # create mock SSM parameter keys
    ssm = SSM(logger, os.environ.get('AWS_REGION'))
    ssm.put_parameter('lock_down_stack_sets_role_flag',
                      flag,
                      'Lock Flag', 'String')
    ssm.put_parameter('/lock_down_role_arns_list/RoleArn1',
                      '"arn:aws:iam::account-id:role/Role1"',
                      'Role Arn 1', 'String')
    ssm.put_parameter('/lock_down_role_arns_list/RoleArn2',
                      '"arn:aws:iam::account-id:role/Role2"',
                      'Role Arn 2', 'String')
