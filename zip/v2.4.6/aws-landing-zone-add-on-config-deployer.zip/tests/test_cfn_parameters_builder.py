##############################################################################
#  Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.   #
#                                                                            #
#  Licensed under the Apache License, Version 2.0 (the "License").           #
#  You may not use this file except in compliance                            #
#  with the License. A copy of the License is located at                     #
#                                                                            #
#      http://www.apache.org/licenses/LICENSE-2.0                            #
#                                                                            #
#  or in the "license" file accompanying this file. This file is             #
#  distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY  #
#  KIND, express or implied. See the License for the specific language       #
#  governing permissions  and limitations under the License.                 #
##############################################################################

from aws.services.cloudformation import StackSet
from lib.logger import Logger
logger = Logger('info')


def test_parameters_builder():
    parameters = {
        "ApplicationId": "App2",
        "EnvironmentType": "EnvType2",
        "EnvironmentNumber": "EnvNum2"
    }
    cfn = StackSet(logger)
    parameters = cfn.build_parameters(parameters)
    for parameter_pair in parameters:
        for key, value in parameter_pair.items():
            assert key in ['ParameterKey', 'ParameterValue']
            if key == 'ParameterKey':
                assert value in ['ApplicationId',
                                 'EnvironmentType',
                                 'EnvironmentNumber']
            if key == 'ParameterValue':
                assert value in ['App2',
                                 'EnvType2',
                                 'EnvNum2']


def test_empty_parameters():
    parameters = {}
    cfn = StackSet(logger)
    parameters = cfn.build_parameters(parameters)
    assert parameters == []

